package com.gradetracker;

import com.gradetracker.exception.StudentNotFoundException;
import com.gradetracker.model.Student;
import com.gradetracker.service.GradeCalculator;
import com.gradetracker.service.StudentManager;
import com.gradetracker.util.InputValidator;

import java.util.Scanner;

/**
 * Main entry point of the Student Grade Tracker application.
 */
public class Main {
    private static StudentManager manager = new StudentManager();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exit = false;

        while (!exit) {
            printMenu();
            int choice = InputValidator.readInt(scanner, "Enter your choice: ");

            switch (choice) {
                case 1 -> addStudent();
                case 2 -> addMarksToStudent();
                case 3 -> calculateGrades();
                case 4 -> displayAllStudents();
                case 5 -> searchStudent();
                case 6 -> updateMarks();
                case 7 -> deleteStudent();
                case 8 -> showTopper();
                case 9 -> showClassStatistics();
                case 10 -> {
                    exit = true;
                    System.out.println("Exiting the application. Goodbye!");
                }
                default -> System.out.println("Invalid choice. Please enter a number between 1 and 10.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n--- Student Grade Tracker ---");
        System.out.println("1. Add Student");
        System.out.println("2. Enter Marks for Subjects");
        System.out.println("3. Calculate Student Grades (Total, Avg, Min/Max, Grade)");
        System.out.println("4. Display All Students");
        System.out.println("5. Search Student");
        System.out.println("6. Update Marks");
        System.out.println("7. Delete Student");
        System.out.println("8. Show Topper");
        System.out.println("9. Display Class Statistics");
        System.out.println("10. Exit");
    }

    private static void addStudent() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        
        manager.addStudent(new Student(id, name));
    }

    private static void addMarksToStudent() {
        try {
            System.out.print("Enter Student ID: ");
            String id = scanner.nextLine();
            Student student = manager.searchStudent(id);

            int numSubjects = InputValidator.readInt(scanner, "How many subjects? ");
            for (int i = 0; i < numSubjects; i++) {
                System.out.print("Enter Subject Name: ");
                String subject = scanner.nextLine();
                double mark = InputValidator.readDouble(scanner, "Enter mark for " + subject + " (0-100): ", 0, 100);
                student.addMark(subject, mark);
            }
            System.out.println("Marks added successfully!");
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void calculateGrades() {
        try {
            System.out.print("Enter Student ID to calculate: ");
            String id = scanner.nextLine();
            Student student = manager.searchStudent(id);

            double total = GradeCalculator.calculateTotal(student);
            double average = GradeCalculator.calculateAverage(student);
            double highest = GradeCalculator.getHighestMark(student);
            double lowest = GradeCalculator.getLowestMark(student);
            String grade = GradeCalculator.getGrade(average);

            System.out.println("\n--- Grades for " + student.getName() + " ---");
            System.out.println("Total Marks: " + total);
            System.out.println("Average: " + average);
            System.out.println("Highest Mark: " + highest);
            System.out.println("Lowest Mark: " + lowest);
            System.out.println("Overall Grade: " + grade);
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void displayAllStudents() {
        System.out.println("\n--- All Students ---");
        if (manager.getAllStudents().isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        for (Student s : manager.getAllStudents()) {
            System.out.println(s);
        }
    }

    private static void searchStudent() {
        try {
            System.out.print("Enter Student ID to search: ");
            String id = scanner.nextLine();
            Student student = manager.searchStudent(id);
            System.out.println("Found: " + student);
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void updateMarks() {
        try {
            System.out.print("Enter Student ID to update marks: ");
            String id = scanner.nextLine();
            Student student = manager.searchStudent(id);

            System.out.print("Enter Subject Name to update: ");
            String subject = scanner.nextLine();
            double mark = InputValidator.readDouble(scanner, "Enter new mark (0-100): ", 0, 100);
            
            student.addMark(subject, mark);
            System.out.println("Marks updated successfully!");
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void deleteStudent() {
        try {
            System.out.print("Enter Student ID to delete: ");
            String id = scanner.nextLine();
            manager.deleteStudent(id);
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void showTopper() {
        try {
            Student topper = manager.getTopper();
            System.out.println("\n--- Class Topper ---");
            System.out.println(topper.getName() + " with Average: " + GradeCalculator.calculateAverage(topper));
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void showClassStatistics() {
        System.out.println("\n--- Class Statistics ---");
        System.out.println("Total Students: " + manager.getAllStudents().size());
        System.out.println("Class Average: " + manager.getClassAverage());
    }
}
