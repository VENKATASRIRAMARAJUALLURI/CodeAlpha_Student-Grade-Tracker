package com.gradetracker.service;

import com.gradetracker.exception.StudentNotFoundException;
import com.gradetracker.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Manages the collection of students and operations on them.
 */
public class StudentManager {
    private List<Student> students;

    public StudentManager() {
        this.students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
        System.out.println("Student added successfully!");
    }

    public List<Student> getAllStudents() {
        return students;
    }

    public Student searchStudent(String id) throws StudentNotFoundException {
        return students.stream()
                .filter(s -> s.getId().equalsIgnoreCase(id))
                .findFirst()
                .orElseThrow(() -> new StudentNotFoundException("Student with ID " + id + " not found."));
    }

    public void deleteStudent(String id) throws StudentNotFoundException {
        Student student = searchStudent(id);
        students.remove(student);
        System.out.println("Student deleted successfully!");
    }

    /**
     * Finds the student with the highest average score.
     */
    public Student getTopper() throws StudentNotFoundException {
        if (students.isEmpty()) {
            throw new StudentNotFoundException("No students in the system.");
        }

        Student topper = students.get(0);
        double maxAverage = GradeCalculator.calculateAverage(topper);

        for (Student student : students) {
            double currentAvg = GradeCalculator.calculateAverage(student);
            if (currentAvg > maxAverage) {
                maxAverage = currentAvg;
                topper = student;
            }
        }
        return topper;
    }

    /**
     * Calculates overall class average based on all students' averages.
     */
    public double getClassAverage() {
        if (students.isEmpty()) return 0.0;
        double totalAvg = students.stream()
                .mapToDouble(GradeCalculator::calculateAverage)
                .sum();
        return totalAvg / students.size();
    }
}
