package com.gradetracker.service;

import com.gradetracker.model.Student;
import java.util.Collection;

/**
 * Utility class to calculate grades and statistics.
 */
public class GradeCalculator {

    public static double calculateTotal(Student student) {
        return student.getMarks().values().stream().mapToDouble(Double::doubleValue).sum();
    }

    public static double calculateAverage(Student student) {
        Collection<Double> marks = student.getMarks().values();
        if (marks.isEmpty()) return 0.0;
        return calculateTotal(student) / marks.size();
    }

    public static double getHighestMark(Student student) {
        return student.getMarks().values().stream().mapToDouble(Double::doubleValue).max().orElse(0.0);
    }

    public static double getLowestMark(Student student) {
        return student.getMarks().values().stream().mapToDouble(Double::doubleValue).min().orElse(0.0);
    }

    /**
     * Determines the grade based on average percentage.
     */
    public static String getGrade(double average) {
        if (average >= 90) return "A+";
        if (average >= 80) return "A";
        if (average >= 70) return "B";
        if (average >= 60) return "C";
        if (average >= 50) return "D";
        return "F";
    }
}
