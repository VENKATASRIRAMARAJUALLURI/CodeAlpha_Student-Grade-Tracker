package com.gradetracker.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a student in the grade tracking system.
 */
public class Student {
    private String id;
    private String name;
    // Map to store subject names and their corresponding marks
    private Map<String, Double> marks;

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.marks = new HashMap<>();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, Double> getMarks() {
        return marks;
    }

    /**
     * Adds or updates a mark for a specific subject.
     */
    public void addMark(String subject, double mark) {
        marks.put(subject, mark);
    }

    @Override
    public String toString() {
        return "Student [ID: " + id + ", Name: " + name + ", Marks: " + marks + "]";
    }
}
