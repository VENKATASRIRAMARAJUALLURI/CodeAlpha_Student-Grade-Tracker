package com.gradetracker.exception;

/**
 * Exception thrown when a requested student is not found.
 */
public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String message) {
        super(message);
    }
}
