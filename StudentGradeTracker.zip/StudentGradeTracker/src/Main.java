import java.util.Scanner;

public class Main {

    public static int getNumberOfStudents(Scanner scanner){
        System.out.println("======================================");
        System.out.println("      STUDENT GRADE TRACKER");
        System.out.println("======================================");
        int numberOfStudents;
        while (true) {
            System.out.print("Enter the number of students: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input! Please enter a valid integer.");
                scanner.next(); // Remove the invalid input
                continue;
            }

            numberOfStudents = scanner.nextInt();

            if (numberOfStudents <= 0) {
                System.out.println("Invalid input! Please enter a positive number greater than 0.");
                continue;
            }

            return numberOfStudents; // Valid input
        }
    }
    public static void displayMarks(int[] studentMarks) {

        System.out.println("\nStudent Marks");
        System.out.println("-------------");

        for (int i = 0; i < studentMarks.length; i++) {
            System.out.println("Student " + (i + 1) + " : " + studentMarks[i]);
        }
    }
    public static void inputMarks(Scanner scanner, int[] studentMarks) {

        System.out.println("\nStudent Marks");

        for (int i = 0; i < studentMarks.length; i++) {

            int marks;

            while (true) {

                System.out.print("Enter marks of Student " + (i + 1) + ": ");

                if (!scanner.hasNextInt()) {
                    System.out.println("Invalid input! Please enter a valid integer.");
                    scanner.next();
                    continue;
                }

                marks = scanner.nextInt();

                if (marks < 0 || marks > 100) {
                    System.out.println("Invalid marks! Enter marks between 0 and 100.");
                    continue;
                }

                break;
            }

            studentMarks[i] = marks;
        }
    }
    public static double[] calculateStatistics(int[] studentMarks) {

        int sum = 0;
        int max = studentMarks[0];
        int min = studentMarks[0];

        for (int mark : studentMarks) {

            sum += mark;

            if (mark > max)
                max = mark;

            if (mark < min)
                min = mark;
        }

        double average = (double) sum / studentMarks.length;

        return new double[]{sum, average, max, min};
    }
    public static void displaySummary(double[] statistics) {

        System.out.println("\n========== RESULT SUMMARY ==========");

        System.out.println("Total Marks   : " + (int) statistics[0]);
        System.out.printf("Average Marks : %.2f%n", statistics[1]);
        System.out.println("Highest Marks : " + (int) statistics[2]);
        System.out.println("Lowest Marks  : " + (int) statistics[3]);

        System.out.println("====================================");
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int numberOfStudents = getNumberOfStudents(scanner);

        int[] studentMarks = new int[numberOfStudents];

        inputMarks(scanner, studentMarks);

        displayMarks(studentMarks);

        double[] statistics = calculateStatistics(studentMarks);

        displaySummary(statistics);

        scanner.close();
    }

}