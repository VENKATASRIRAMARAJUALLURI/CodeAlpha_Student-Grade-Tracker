# Student Grade Tracker

A professional Java console application to track student grades, calculate statistics, and manage student records. Built using Java 17 and Object-Oriented Programming (OOP) principles.

## Features
1. **Add Student**: Add a new student by providing an ID and Name.
2. **Enter Marks**: Enter marks for multiple subjects (0-100 validation).
3. **Calculate Grades**: Calculate Total, Average, Highest Mark, Lowest Mark, and Overall Grade (A+, A, B, C, D, F).
4. **Display All**: View a list of all students and their marks.
5. **Search**: Find a specific student by their ID.
6. **Update Marks**: Update existing marks for a subject.
7. **Delete Student**: Remove a student record.
8. **Show Topper**: Find the student with the highest average.
9. **Display Statistics**: See the total number of students and overall class average.

## Project Structure
The project follows clean architecture and separation of concerns:
- `model`: Contains data classes like `Student`.
- `service`: Contains business logic like `StudentManager` and `GradeCalculator`.
- `exception`: Custom exceptions like `StudentNotFoundException`.
- `util`: Utility classes like `InputValidator` for safe console input.

## How to Run
1. Ensure you have Java 17 or higher installed.
2. Navigate to the `src` directory.
3. Compile the Java files:
   ```bash
   javac com/gradetracker/**/*.java com/gradetracker/Main.java
   ```
4. Run the application:
   ```bash
   java com.gradetracker.Main
   ```
